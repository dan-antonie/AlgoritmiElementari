//
//  ViewController.h
//  InterviuTest
//
//  Created by Horatiu on 03/02/16.
//  Copyright © 2016 Horatiu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyComent.h"
@interface ViewController : UIViewController


@end

