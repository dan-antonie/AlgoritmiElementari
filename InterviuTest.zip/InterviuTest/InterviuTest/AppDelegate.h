//
//  AppDelegate.h
//  InterviuTest
//
//  Created by Horatiu on 03/02/16.
//  Copyright © 2016 Horatiu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

